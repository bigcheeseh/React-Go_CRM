export const SAVE_CONTACT = "SAVE_CONTACT";
export const FILTR_CONTACTS = "FILTR_CONTACTS";
export const FETCH_CONTACTS = "FETCH_CONTACTS";
export const FETCH_CONTACT ="FETCH_CONTACT"; 
export const EXPORT_CONTACTS = "EXPORT_CONTACTS";
export const IMPORT_CONTACTS="IMPORT_CONTACTS"

export const DELETE_CONTACT = "DELETE_CONTACT";
export const COMMON_SEARCH = "COMMON_SEARCH";
export const UPDATE_CONTACT = "UPDATE_CONTACT";
export const ADD_LINK = "ADD_LINK";

export const ADD_NOTE ="ADD_NOTE";

export const UPLOAD_FILE ="UPLOAD_FILE";


export const SET_NOTES = "SET_NOTES"
export const SET_LINKS = "SET_LINKS"
export const CLEAR_NOTES="CLEAR_NOTES"
export const CLEAR_LINKS="CLEAR_LINKS"

export const DELETE_LINK = "DELETE_LINK";


export const DELETE_NOTE = "DELETE_NOTE";
export const ERROR = "ERROR";




export const LOGIN = "LOGIN";
export const LOGOUT = "LOGOUT";